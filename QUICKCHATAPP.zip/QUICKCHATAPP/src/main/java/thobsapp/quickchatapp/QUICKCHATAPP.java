/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package thobsapp.quickchatapp;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import thobsapp.quickchatapp.MESSAGE;
/**
 *
 * @author RC_Student_Lab
 */
public class QUICKCHATAPP {

    // Inner class for MESSAGE containing Message and Action
    public static class MESSAGE {
        public class Message {
            public enum Action {
                SEND, DISCARD, STORE
            }

            private String messageId;
            private int index;
            private String recipient;
            private String text;
            private Action action;
            private static int totalMessages = 0; // Static to track across instances

            public Message(String id, int index, String recipient, String text, Action action) {
                this.messageId = id;
                this.index = index;
                this.recipient = recipient;
                this.text = text;
                this.action = action;
                if (action == Action.SEND) totalMessages++;
            }

            // Basic validation for rubric compliance
            public static String validateBodyForRubric(String body) {
                if (body == null || body.length() > 250) {
                    return "Message body must be <= 250 characters.";
                }
                return "Message ready to send.";
            }

            public static String generateId10() {
                String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                Random random = new Random();
                StringBuilder id = new StringBuilder();
                for (int i = 0; i < 10; i++) {
                    id.append(characters.charAt(random.nextInt(characters.length())));
                }
                return id.toString();
            }

            public boolean checkRecipientCell() {
                return recipient != null && recipient.matches("^\\+\\d{11,}$"); // e.g., +27123456789
            }

            public String sendMessage() {
                if (checkRecipientCell()) {
                    return "Message sent successfully.";
                }
                return "Failed to send: Invalid recipient number.";
            }

            public void storeMessage() {
                JOptionPane.showMessageDialog(null, "Message stored for later.");
            }

            public String getMessageId() { return messageId; }
            public String getMessageHashPublic() { return "HASH_" + messageId; } // Placeholder hash
            public String getRecipient() { return recipient; }
            public String getText() { return text; }
            public Action getAction() { return action; }

            public static int returnTotalMessages() {
                return totalMessages;
            }
        }
    }

    // Minimal LOGIN class implementation
    public static class LOGIN {
        private String firstName, lastName, username, password, phone;
        private int attempts;

        public LOGIN(String first, String last, String user, String pass, String phone) {
            this.firstName = first;
            this.lastName = last;
            this.username = user;
            this.password = pass;
            this.phone = phone;
        }

        public String registerUser() {
            if (checkUserName() && checkPasswordComplexity() && checkCellPhoneNumber()) {
                return "Registration successful.";
            }
            return "Registration failed. Please check your input.";
        }

        public boolean checkUserName() {
            return username.contains("_") && username.length() <= 5;
        }

        public boolean checkPasswordComplexity() {
            return password.length() >= 8 && password.matches(".[A-Z].") && password.matches(".\\d.") && password.matches(".[!@#$%^&].*");
        }

        public boolean checkCellPhoneNumber() {
            return phone.matches("^\\+\\d{11,}$"); // e.g., +27123456789
        }

        public boolean loginUser(String u, String p) {
            return u.equals(username) && p.equals(password);
        }

        public String returnLoginStatus(boolean ok) {
            return ok ? "Login successful." : "Login failed. Attempts left: " + (2 - attempts);
        }
    }

    public static void main(String[] args) {
        // -------------------- PART 1: SIGN-UP VIA JOptionPane --------------------
        LOGIN login = null;

        while (true) {
            String first = JOptionPane.showInputDialog("=== Registration ===\nEnter First name:");
            if (first == null) return; // user cancelled
            String last = JOptionPane.showInputDialog("Enter Last name:");
            if (last == null) return;

            String user = JOptionPane.showInputDialog("Create Username (must contain '_' and be <= 5 chars):");
            if (user == null) return;

            String pass = JOptionPane.showInputDialog("Create Password (>=8, include UPPERCASE, number, special):");
            if (pass == null) return;

            String phone = JOptionPane.showInputDialog("Enter Cellphone in international format (e.g. +27#########):");
            if (phone == null) return;

            login = new LOGIN(first.trim(), last.trim(), user.trim(), pass, phone.trim());

            // use the same messages 
            String regMsg = login.registerUser();
            JOptionPane.showMessageDialog(null, regMsg);

            //Stop or exit the loop only if every condition is true.
            if (login.checkUserName() && login.checkPasswordComplexity() && login.checkCellPhoneNumber()) {
                break; // successful registration
            } else {
                JOptionPane.showMessageDialog(null, "Please fix the issues above and try registration again.");
            }
        }

        // -------------------- PART 1: LOGIN VIA JOptionPane ----------------------
        boolean ok = false;
        int attempts = 0;
        while (attempts < 3) {
            String u = JOptionPane.showInputDialog("=== Login ===\nEnter username:");
            if (u == null) return;
            String p = JOptionPane.showInputDialog("Enter password:");
            if (p == null) return;

            ok = login.loginUser(u.trim(), p);
            JOptionPane.showMessageDialog(null, login.returnLoginStatus(ok));
            if (ok) break;
            attempts++;
        }
        if (!ok) return; // must be logged in to proceed

        // -------------------- PART 2: MENU + MESSAGING --------------------------
        List<MESSAGE.Message> history = new ArrayList<>(); // Using inner class
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        while (true) {
            String choice = JOptionPane.showInputDialog(
                    """
                    Welcome to QuickChat.
                    Choose an option:
                    1) Send Messages
                    2) Show recently sent messages (Coming Soon)
                    3) Quit
                    """);
            if (choice == null) break;

            switch (choice.trim()) {
                case "1" -> {
                    int howMany = askIntBounded("How many messages would you like to enter?", 1, 20);
                    int i = 1; // Changed to while loop for rubric compliance
                    while (i <= howMany) {
                        String recipient = JOptionPane.showInputDialog("Enter recipient number (e.g. +27718693002):");
                        if (recipient == null) break;

                        String body = JOptionPane.showInputDialog("Enter message text (<= 250 characters):");
                        if (body == null) break;

                        String lenMsg = MESSAGE.Message.validateBodyForRubric(body);
                        JOptionPane.showMessageDialog(null, lenMsg);
                        if (!lenMsg.startsWith("Message ready")) {
                            body = JOptionPane.showInputDialog("Re-enter message (<= 250 characters):");
                            if (body == null) break;
                        }

                        String actionStr = JOptionPane.showInputDialog(
                                """
                                Choose what to do with this message:
                                1) Send Message
                                2) Disregard Message
                                3) Store Message to send later
                                """);
                        if (actionStr == null || !actionStr.trim().matches("[123]")) {
                            JOptionPane.showMessageDialog(null, "Invalid option. Please enter 1, 2, or 3.");
                            continue;
                        }
                        MESSAGE.Message.Action action = switch (actionStr.trim()) {
                            case "1" -> MESSAGE.Message.Action.SEND;
                            case "2" -> MESSAGE.Message.Action.DISCARD;
                            case "3" -> MESSAGE.Message.Action.STORE;
                            default -> MESSAGE.Message.Action.DISCARD;
                        };

                        String id = MESSAGE.Message.generateId10();
                        MESSAGE messageInstance = new MESSAGE(); // Enclosing instance
                        MESSAGE.Message msg = messageInstance.new Message(id, i, recipient.trim(), body, action);

                        if (!msg.checkRecipientCell()) {
                            JOptionPane.showMessageDialog(null,
                                    "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                            continue; // If the recipient is wrong, move on to the next one
                        }

                        JOptionPane.showMessageDialog(null, msg.sendMessage());
                        if (action == MESSAGE.Message.Action.STORE) msg.storeMessage();
                        if (action != MESSAGE.Message.Action.DISCARD) history.add(msg);

                        if (action == MESSAGE.Message.Action.SEND) {
                            JOptionPane.showMessageDialog(null,
                                    "MessageID: " + msg.getMessageId() + "\n" +
                                    "Message Hash: " + msg.getMessageHashPublic() + "\n" +
                                    "Recipient: " + msg.getRecipient() + "\n" +
                                    "Message: " + msg.getText());
                        }
                        i++;
                    }
                    JOptionPane.showMessageDialog(null,
                            "Total number of messages sent: " + MESSAGE.Message.returnTotalMessages());
                }
                case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                case "3" -> { return; }
                default -> JOptionPane.showMessageDialog(null, "Please choose 1, 2 or 3.");
            }
        }
    }

    // ensure valid numeric input
    private static int askIntBounded(String prompt, int min, int max) {
        while (true) {
            String s = JOptionPane.showInputDialog(prompt + " (" + min + "-" + max + ")");
            if (s == null) return min;
            try {
                int n = Integer.parseInt(s.trim());
                if (n >= min && n <= max) return n;
            } catch (NumberFormatException ignored) {}
            JOptionPane.showMessageDialog(null, "Please enter a valid number between " + min + " and " + max + ".");
        }
    }
}